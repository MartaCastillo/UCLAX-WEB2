var boxes = document.querySelectorAll('.box');

  console.log(boxes);

/*Red Box -----------------------------*/
  boxes[0].addEventListener('click', function(){
    boxes[0].classList.toggle('on');
  });

/*Green Box -----------------------------*/
  boxes[1].addEventListener('click', function(){
    boxes[1].classList.toggle('on');
  });

/*Blue Box -----------------------------*/
  boxes[2].addEventListener('click', function(){
    boxes[2].classList.toggle('on');
  });

 /*Cyan Box -----------------------------*/
  boxes[3].addEventListener('click', function(){
    boxes[3].classList.toggle('on');
  });

 /*Magenta Box -----------------------------*/
  boxes[4].addEventListener('click', function(){
    boxes[4].classList.toggle('on');
  });

 /*Yellow Box -----------------------------*/
  boxes[5].addEventListener('click', function(){
    boxes[5].classList.toggle('on');
  });